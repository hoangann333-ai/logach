package com.codegym.dao;

import com.codegym.model.User;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** JDBC implementation of the user persistence operations. */
public class UserDAO implements IUserDAO {
    private static final String JDBC_URL = System.getenv().getOrDefault(
            "DB_URL", "jdbc:mysql://localhost:3306/demo?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
    private static final String JDBC_USERNAME = System.getenv().getOrDefault("DB_USER", "root");
    private static final String JDBC_PASSWORD = System.getenv().getOrDefault("DB_PASSWORD", "password");

    private static final String SQL_INSERT =
            "INSERT INTO Employee (name, salary, created_Date) VALUES (?, ?, ?)";
    private static final String SQL_UPDATE =
            "UPDATE Employee SET salary = ? WHERE name = ?";
    private static final String SQL_TABLE_CREATE = "CREATE TABLE Employee ("
            + "id INT AUTO_INCREMENT PRIMARY KEY, "
            + "name VARCHAR(100) NOT NULL, "
            + "salary DECIMAL(15, 2) NOT NULL, "
            + "created_Date TIMESTAMP)";
    private static final String SQL_TABLE_DROP = "DROP TABLE IF EXISTS Employee";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
    }

    @Override
    public void insertUser(User user) throws SQLException {
        String sql = "INSERT INTO users (name, email, country) VALUES (?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.executeUpdate();
        }
    }

    @Override
    public User selectUser(int id) throws SQLException {
        String sql = "SELECT id, name, email, country FROM users WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapUser(resultSet);
                }
            }
        }
        return null;
    }

    @Override
    public List<User> selectAllUsers() throws SQLException {
        String sql = "SELECT id, name, email, country FROM users ORDER BY id";
        List<User> users = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                users.add(mapUser(resultSet));
            }
        }
        return users;
    }

    @Override
    public boolean deleteUser(int id) throws SQLException {
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE users SET name = ?, email = ?, country = ? WHERE id = ?";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.setInt(4, user.getId());
            return statement.executeUpdate() > 0;
        }
    }

    @Override
    public User getUserById(int id) throws SQLException {
        String sql = "{CALL get_user_by_id(?)}";
        try (Connection connection = getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new User(id,
                            resultSet.getString("name"),
                            resultSet.getString("email"),
                            resultSet.getString("country"));
                }
            }
        }
        return null;
    }

    @Override
    public void insertUserStore(User user) throws SQLException {
        String sql = "{CALL insert_user(?, ?, ?)}";
        try (Connection connection = getConnection();
             CallableStatement statement = connection.prepareCall(sql)) {
            statement.setString(1, user.getName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getCountry());
            statement.executeUpdate();
        }
    }

    /**
     * Demonstrates partial writes with JDBC's default auto-commit behavior.
     * The missing value for UPDATE parameter 1 is deliberate for this exercise.
     */
    @Override
    public void insertUpdateWithoutTransaction() throws SQLException {
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             PreparedStatement insert = connection.prepareStatement(SQL_INSERT);
             PreparedStatement update = connection.prepareStatement(SQL_UPDATE)) {

            // Reset only the Employee test table. This method does not disable auto-commit.
            statement.execute(SQL_TABLE_DROP);
            statement.execute(SQL_TABLE_CREATE);

            insert.setString(1, "Quynh");
            insert.setBigDecimal(2, new BigDecimal("10.00"));
            insert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            insert.executeUpdate();

            insert.setString(1, "Ngan");
            insert.setBigDecimal(2, new BigDecimal("20.00"));
            insert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            insert.executeUpdate();

            // Intentional bug: parameter 1 (salary) is never set.
            update.setBigDecimal(2, new BigDecimal("999.99"));
            // Correct line would be: update.setBigDecimal(1, new BigDecimal("999.99"));
            update.setString(2, "Quynh");
            update.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Đã bắt được lỗi trong quá trình thực thi SQL:");
            e.printStackTrace();
        }
    }

    private User mapUser(ResultSet resultSet) throws SQLException {
        return new User(
                resultSet.getInt("id"),
                resultSet.getString("name"),
                resultSet.getString("email"),
                resultSet.getString("country"));
    }
}
