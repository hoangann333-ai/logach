USE demo;

CREATE TABLE IF NOT EXISTS Employee (
    id INT AUTO_INCREMENT NOT NULL,
    name VARCHAR(100) NOT NULL,
    salary DECIMAL(15, 2) NOT NULL,
    created_Date TIMESTAMP,
    PRIMARY KEY (id)
);

-- Verify the test data after requesting /users?action=test-without-tran:
-- SELECT * FROM Employee;
